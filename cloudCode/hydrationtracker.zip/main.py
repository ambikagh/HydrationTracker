# A lambda function to interact with AWS RDS MySQL

import pymysql
import sys
import rds_config
import boto3
import json

REGION = 'us-west-2'

rds_host  = rds_config.db_host
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

iot_client = boto3.client('iot-data', region_name = "us-west-2")

def track_water_consumption(event, context):
    """
    This function tracks water consumed by a user.
    Every message contains water consumption information (weight) and user id. 
    Lambda function calculates the new_weight by adding received weight 
		and weight fetched from mysql db.
    Stores the new_weight back into mysql db.
    """
    result = []
    
    current_weight = float(event['weight']) # Water consumed by user
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        # Fetch the weight from db
        cur.execute("""select weight from water_table order by id desc limit 1""")
        new_weight = float(0)
        for row in cur:
            new_weight = float(list(row)[0]) + current_weight
            print new_weight
            
        # store the calculated new weight back into db    
        cur.execute("""INSERT INTO water_table (iduser, weight ) VALUES (%s, '%s')""" % (1, str(new_weight)))
        cur.execute('''select * from water_table''')
        
        for row in cur:
            print row
            result.append(list(row))
        conn.commit()
        cur.close()
        print "Data from RDS..."
        print result
        
    # for testing    
    response = iot_client.publish(
                                topic='fromLambda/01',
                                qos=1,
                                payload=json.dumps(event)
                            )

def main(event, context):
    track_water_consumption(event, context)
		

                        