# A lambda function to interact with AWS RDS MySQL

import pymysql
import sys
import rds_config

REGION = 'us-west-2'

rds_host  = rds_config.db_host
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name

def save_events(event, context):
    """
    This function fetches content from mysql RDS instance
    """    
		ts = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
    with conn.cursor() as cur:
        cur.execute("""INSERT INTO water_table (iduser, weight ) VALUES (%s, '%s')""" % (1, '0'))
        #cur.execute(sql, (3, 'Johnny Depp', '221', '160'))
        cur.execute('''select * from user''')
        for row in cur:
            result.append(list(row))
        conn.commit()
        cur.close()
        print "Data from RDS..."
        print result

def main(event, context):
    save_events(event, context)
		
