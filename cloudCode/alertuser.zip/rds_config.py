#config file containing credentials for rds mysql instance
db_host  = "iotproj.c4yg2hntdojr.us-west-2.rds.amazonaws.com"
db_username = "iotproj"
db_password = "iotprojpassword"
db_name = "iotuser"