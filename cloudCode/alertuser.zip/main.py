import pymysql
import sys
import rds_config
import boto3
import json
from datetime import datetime, date, time

REGION = 'us-west-2'

rds_host  = rds_config.db_host
name = rds_config.db_username
password = rds_config.db_password
db_name = rds_config.db_name


client = boto3.client('sns')
iot_client = boto3.client('iot-data', region_name = "us-west-2")


def notify_user(event, context):
	result = []
	minutes = 0
	conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
	with conn.cursor() as cur:
		#format = "%Y-%m-%d %H:%M:%S"
		# get the current timestamp
		ct2 = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
		# convert string to datetime format
		t2 = datetime.strptime(ct2, "%Y-%m-%d %H:%M:%S")
		# Fetch the latest time from db        
		cur.execute("""select date from water_table order by id desc limit 1""")            
		for row in cur:
			#t1 = datetime.strptime(list(row)[0], "%Y-%m-%d %H:%M:%S")
			t1 = list(row)[0]
			print t1
		sec = (t2 - t1).seconds
		minutes = sec / 60
		print "sec = {0}, min = {1}".format(sec, minutes)
		conn.commit()
		cur.close()
		print "Data from RDS..."
		print result
	
	if minutes > 3:   
		# Send SMS alerts to the user
		response_SNS = client.publish(
			TargetArn = 'arn:aws:sns:us-west-2:791683861434:testSNS',
			#Message=json.dumps({'default': json.dumps(message)}),
			Message =  "Take a break. Get hydrated and feel better :)",
			MessageStructure='string'
		)
		
		# send led alerts
		response = iot_client.publish(
			topic='ledAlert/01',
			qos=1,
			payload=json.dumps(event)
		)
		print 'time to drink water'
	else:
		print 'love the water'

def main(event, context):
   notify_user(event, context)